package com.suib.mediation.admob;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.mediation.MediationAdRequest;
import com.google.android.gms.ads.mediation.customevent.CustomEventInterstitial;
import com.google.android.gms.ads.mediation.customevent.CustomEventInterstitialListener;
import com.suib.base.callback.AdEventListener;
import com.suib.base.core.SuibSDK;
import com.suib.base.core.ZCNative;
import com.suib.base.vo.AdsNativeVO;

public class ZCustomEventInterstitial implements CustomEventInterstitial {
    private ZCNative result;
    private static final String TAG = "ZCEventInterstitial";
    private CustomEventInterstitialListener interstitialListener;


    @Override
    public void requestInterstitialAd(Context context, CustomEventInterstitialListener customEventInterstitialListener, String serverParameter, MediationAdRequest mediationAdRequest, Bundle bundle) {
        interstitialListener = customEventInterstitialListener;
        Log.e(TAG, "requestInterstitialAd: Admob -> " + serverParameter);
        if (!(context instanceof Activity)) {
            Log.w(TAG, "Context must be of type Activity.");
            if (interstitialListener != null) {
                interstitialListener.onAdFailedToLoad(AdRequest.ERROR_CODE_NO_FILL);
            }
            return;
        }
        SuibSDK.initialize(context, serverParameter);
        SuibSDK.preloadInterstitialAd(context, serverParameter, ctAdEventListener);
    }


    @Override
    public void showInterstitial() {
        if (!SuibSDK.isInterstitialAvailable(result)) {
            if (interstitialListener != null) {
                interstitialListener.onAdFailedToLoad(AdRequest.ERROR_CODE_INTERNAL_ERROR);
            }
            return;
        }
        SuibSDK.showInterstitialAd(result);
    }


    @Override
    public void onDestroy() {

    }


    @Override
    public void onPause() {

    }


    @Override
    public void onResume() {

    }


    private AdEventListener ctAdEventListener = new AdEventListener() {
        @Override
        public void onReceiveAdSucceed(ZCNative result) {
            if (interstitialListener != null) {
                interstitialListener.onAdLoaded();
            }
            ZCustomEventInterstitial.this.result = result;
        }


        @Override
        public void onReceiveAdVoSucceed(AdsNativeVO result) {

        }


        @Override
        public void onInterstitialLoadSucceed(ZCNative result) {
            if (interstitialListener != null) {
                interstitialListener.onAdOpened();
            }
        }


        @Override
        public void onReceiveAdFailed(ZCNative result) {
            if (interstitialListener != null) {
                interstitialListener.onAdFailedToLoad(AdRequest.ERROR_CODE_NO_FILL);
            }
        }


        @Override
        public void onLandpageShown(ZCNative result) {

        }


        @Override
        public void onAdClicked(ZCNative result) {
            if (interstitialListener != null) {
                interstitialListener.onAdClicked();
            }
        }


        @Override
        public void onAdClosed(ZCNative result) {
            if (interstitialListener != null) {
                interstitialListener.onAdClosed();
            }
        }

    };
}
