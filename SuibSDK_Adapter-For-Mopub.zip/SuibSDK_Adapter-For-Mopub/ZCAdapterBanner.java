package com.suib.mediation.mopub;

import android.content.Context;
import android.content.res.Resources;
import android.util.DisplayMetrics;
import android.util.Log;

import com.mopub.mobileads.CustomEventBanner;
import com.mopub.mobileads.MoPubErrorCode;
import com.suib.base.callback.AdEventListener;
import com.suib.base.core.SuibSDK;
import com.suib.base.core.ZCNative;
import com.suib.base.enums.AdSize;
import com.suib.base.vo.AdsNativeVO;

import java.util.Map;

public class ZCAdapterBanner extends CustomEventBanner {

    private static final String TAG = "CTAdapterBanner";


    @Override
    protected void loadBanner(final Context context, final CustomEventBannerListener customEventBannerListener, Map<String, Object> localExtras, Map<String, String> serverExtras) {
        final String adUnitId;
        Log.i(TAG,
            "loadBanner: localExtras -> " + localExtras + ", serverExtras -> " + serverExtras);

        if (extrasAreValid(serverExtras)) {
            adUnitId = serverExtras.get(ZCHelper.KEY_CT_SLOTID);
        } else {
            customEventBannerListener.onBannerFailed(MoPubErrorCode.INTERNAL_ERROR);
            return;
        }

        SuibSDK.initialize(context, adUnitId);

        AdSize ctAdSize = AdSize.AD_SIZE_320X50;

        SuibSDK.getBannerAd(context, adUnitId, ctAdSize,
            new AdEventListener() {
                @Override
                public void onReceiveAdSucceed(ZCNative zcNative) {
                    if (zcNative != null) {
                        customEventBannerListener.onBannerLoaded(zcNative);
                    } else {
                        customEventBannerListener.onBannerFailed(
                            MoPubErrorCode.NETWORK_INVALID_STATE);
                    }
                }


                @Override
                public void onReceiveAdVoSucceed(AdsNativeVO result) {

                }


                @Override
                public void onInterstitialLoadSucceed(ZCNative result) {

                }


                @Override
                public void onReceiveAdFailed(ZCNative result) {
                    customEventBannerListener.onBannerFailed(MoPubErrorCode.NETWORK_NO_FILL);
                }


                @Override
                public void onLandpageShown(ZCNative result) {

                }


                @Override
                public void onAdClicked(ZCNative result) {
                    customEventBannerListener.onBannerClicked();
                }


                @Override
                public void onAdClosed(ZCNative result) {
                    customEventBannerListener.onBannerCollapsed();
                }

            });
    }


    @Override
    protected void onInvalidate() {
    }


    private boolean extrasAreValid(final Map<String, String> serverExtras) {
        return (serverExtras != null) && serverExtras.containsKey(ZCHelper.KEY_CT_SLOTID);
    }


    private int dpToPx(int dp) {
        DisplayMetrics displayMetrics = Resources.getSystem().getDisplayMetrics();
        return (int) (dp * displayMetrics.density + .5f);
    }
}
