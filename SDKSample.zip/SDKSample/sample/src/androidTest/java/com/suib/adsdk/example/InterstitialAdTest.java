package com.suib.adsdk.example;

import android.app.Instrumentation;
import android.support.test.InstrumentationRegistry;
import android.support.test.espresso.DataInteraction;
import android.support.test.espresso.FailureHandler;
import android.support.test.espresso.IdlingPolicies;
import android.support.test.espresso.IdlingRegistry;
import android.support.test.espresso.intent.rule.IntentsTestRule;
import android.support.test.filters.LargeTest;
import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;

import com.suib.adsdk.example.utils.Constants;
import com.suib.adsdk.example.utils.RepeatRule;

import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.concurrent.TimeUnit;

import static android.support.test.espresso.Espresso.onData;
import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.Espresso.openActionBarOverflowOrOptionsMenu;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.assertion.ViewAssertions.matches;
import static android.support.test.espresso.matcher.ViewMatchers.isDisplayed;
import static android.support.test.espresso.matcher.ViewMatchers.withClassName;
import static android.support.test.espresso.matcher.ViewMatchers.withId;
import static android.support.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.anything;
import static org.hamcrest.Matchers.endsWith;

/**
 * Created by tujiantao on 2018/3/5.
 */
@LargeTest
@RunWith(AndroidJUnit4.class)
public class InterstitialAdTest {

    private final static String TAG = "InterstitialAdTest";

    @Rule
    public RepeatRule repeatRule = new RepeatRule();

    @Rule
    public ActivityTestRule<MainActivity> mActivityTestRule = new ActivityTestRule<>(MainActivity
        .class);

    @Rule
    public IntentsTestRule<com.suib.base.view.InterstitialActivity> interstitialActivityTestRule = new IntentsTestRule<>(com.suib.base.view.InterstitialActivity.class);

    private SimpleCountingIdlingResource getAdIdlingResource;

    private MainActivity activity;

    private Instrumentation instrumentation;

    @BeforeClass
    public static void startClass(){
        IdlingPolicies.setMasterPolicyTimeout(20, TimeUnit.SECONDS);
        IdlingPolicies.setIdlingResourceTimeout(20, TimeUnit.SECONDS);
    }

    @Before
    public void start() throws InterruptedException {
        instrumentation=InstrumentationRegistry.getInstrumentation();
//        UiDevice.getInstance(instrumentation).runWatchers();
//        PermissionsUtil.checkDialog();
        activity = mActivityTestRule.getActivity();

        //        if (!PowersUtil.getScreenOn(activity) || PowersUtil.getLockScreenOn(activity)) {//解锁屏幕
        //            PowersUtil.wakeUpAndUnlock(activity);
        //        }
        Thread.sleep(2000);
        //点击横竖屏
        openActionBarOverflowOrOptionsMenu(InstrumentationRegistry.getTargetContext());
        onView(withText("hvScreen")).perform(click());

        //点击进入插屏广告
        DataInteraction appCompatTextView = onData(anything())
            .inAdapterView(allOf(withId(R.id.listView),
                childAtPosition(withId(R.id.main_content), 0))).atPosition(1);
        appCompatTextView.perform(click());
    }

    @Test
    @RepeatRule.Repeat( runCount =  Constants.TEST_COUNT )
    public void loadAdSuccess() {
        getAdIdlingResource = SimpleCountingIdlingResource.create("test2");
        IdlingRegistry.getInstance().register(getAdIdlingResource);
        Log.i(TAG, "threadId=" + Thread.currentThread().getId() + ",processName=" + Thread
            .currentThread().getName());
        Log.i(TAG, "LOAD AD SUCCESS 点击前");
        onView(allOf(withId(R.id.loadButton),withText("LOAD AD"))).perform(click());
        Log.i(TAG, "LOAD AD SUCCESS");
        sleep(4000L);
        onView(withClassName(endsWith("WebView")))
            .check(matches(isDisplayed())).withFailureHandler(new FailureHandler() {
            @Override
            public void handle(Throwable error, Matcher<View> viewMatcher) {
                System.out.print("校验不合格 error="+error.getMessage()+",viewMatcher="+viewMatcher.toString());
                throw new RuntimeException(error);
            }
        });

    }


    @After
    public void stop() {
        IdlingRegistry.getInstance().unregister(getAdIdlingResource);
    }

    private void sleep(Long time){
        try {
            Thread.sleep(time);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private static Matcher<View> childAtPosition(
        final Matcher<View> parentMatcher, final int position) {

        return new TypeSafeMatcher<View>() {
            @Override
            public void describeTo(Description description) {
                description.appendText("Child at position " + position + " in parent ");
                parentMatcher.describeTo(description);
            }

            @Override
            public boolean matchesSafely(View view) {
                ViewParent parent = view.getParent();
                return parent instanceof ViewGroup && parentMatcher.matches(parent)
                    && view.equals(((ViewGroup) parent).getChildAt(position));
            }
        };
    }

}