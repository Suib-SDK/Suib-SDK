package com.suib.adsdk.example.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.suib.adsdk.example.R;
import com.suib.adsdk.example.config.Config;
import com.suib.adsdk.example.listener.MyCTAdEventListener;
import com.suib.base.core.SuibSDK;

import java.util.Random;

/**
 * Created by longzhang on 7/26/16.
 */
public class BannerAdFragment extends Fragment {

    private ViewGroup container;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater,
                             @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_banner, null);
        initView(view);
        return view;
    }


    private void initView(View view) {

        container = (ViewGroup) view.findViewById(R.id.container);

        view.findViewById(R.id.load_ad).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loadAd();
            }
        });

    }


    private static final String TAG = "BannerAdFragment";


    public void loadAd() {
        // 获取横幅广告，返回一个含有广告的容器
        int index = new Random().nextInt(com.suib.base.enums.AdSize.values().length);
        com.suib.base.enums.AdSize adSize = com.suib.base.enums.AdSize.values()[index];

        SuibSDK.getBannerAd(getActivity(), Config.slotIdBanner, adSize,
                new MyCTAdEventListener() {
                    @Override
                    public void onReceiveAdSucceed(com.suib.base.core.ZCNative result) {
                        if (result != null) {
                            container.setVisibility(View.VISIBLE);
                            container.removeAllViews();
                            container.addView(result);   //把广告添加到容器

                        }

                        super.onReceiveAdSucceed(result);
                    }


                    @Override
                    public void onReceiveAdFailed(com.suib.base.core.ZCNative result) {

                        super.onReceiveAdFailed(result);
                    }


                    @Override
                    public void onAdClicked(com.suib.base.core.ZCNative result) {

                        super.onAdClicked(result);
                    }


                    @Override
                    public void onAdClosed(com.suib.base.core.ZCNative result) {

                        container.removeAllViews();
                        container.setVisibility(View.GONE);

                        super.onAdClosed(result);
                    }
                });

    }

}
