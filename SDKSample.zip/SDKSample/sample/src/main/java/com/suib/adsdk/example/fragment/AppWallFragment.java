package com.suib.adsdk.example.fragment;

import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.suib.adsdk.example.MainActivity;
import com.suib.adsdk.example.R;
import com.suib.adsdk.example.config.Config;
import com.suib.appwall.SuibAppwall;
import com.suib.base.core.SuibSDK;

public class AppWallFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater,
                             @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_appwall, null);
        initView(view);
        return view;
    }


    private void initView(View view) {

        view.findViewById(R.id.init_appwall).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                SuibAppwall.preloadAppwall(getContext(), Config.slotIdAppWall);

            }
        });

        view.findViewById(R.id.show_appwall_new_activity)
                .setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        if (!SuibSDK.isInitialized()) {
                            Toast.makeText(view.getContext(), "No initialization, please call the initialize function.",
                                    Toast.LENGTH_SHORT).show();
                            return;
                        }

                        //Optional
                        com.suib.appwall.CustomizeColor custimozeColor = new com.suib.appwall.CustomizeColor();
                        custimozeColor.setMainThemeColor(Color.parseColor("#ff0000ff"));
                        SuibAppwall.setThemeColor(custimozeColor);

                        //Optional
                        SuibAppwall.setActivityAnimation(R.anim.fade_in, R.anim.fade_out);
                        SuibAppwall.showAppwall(getContext(), Config.slotIdAppWall);

                    }
                });

        view.findViewById(R.id.show_appwall_natvie_fragment)
                .setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        if (!SuibSDK.isInitialized()) {
                            Toast.makeText(view.getContext(), "No initialization, please call the initialize function.",
                                    Toast.LENGTH_SHORT).show();
                            return;
                        }
                        //Optional
                        com.suib.appwall.CustomizeColor custimozeColor = new com.suib.appwall.CustomizeColor();
                        custimozeColor.setMainThemeColor(Color.parseColor("#ffff0000"));
                        SuibAppwall.setThemeColor(custimozeColor);

                        android.app.Fragment fragment = SuibAppwall.getAppwallFragment(getContext(),
                                Config.slotIdAppWall);
                        ((MainActivity) getActivity()).showNativeFragment(fragment);
                    }
                });

    }

}
