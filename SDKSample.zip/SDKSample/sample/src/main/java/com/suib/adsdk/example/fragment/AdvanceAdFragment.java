package com.suib.adsdk.example.fragment;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.suib.adsdk.example.AdHolder;
import com.suib.adsdk.example.R;
import com.suib.adsdk.example.SampleApplication;
import com.suib.adsdk.example.config.Config;
import com.suib.adsdk.example.listener.MyCTAdEventListener;
import com.facebook.drawee.view.SimpleDraweeView;
import com.suib.base.core.ZCAdvanceNative;
import com.suib.base.core.ZCNative;
import com.suib.base.core.SuibSDK;
import com.suib.base.utils.SLog;

public class AdvanceAdFragment extends Fragment {

    private ViewGroup container;
    private ViewGroup adLayout;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_advance_native, null);
        initView(view);
        return view;
    }

    private final static String TAG = "AdvanceAdTest";

    private void initView(View view) {
        container = (ViewGroup) view.findViewById(R.id.container);                         //媒体容器

        view.findViewById(R.id.load_ad).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loadAd();
                Log.i(TAG, "loadAd");
            }
        });


        view.findViewById(R.id.load_for_cache).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                loadAdForCache();
                Log.i(TAG, "loadAdForCache");

            }
        });

        view.findViewById(R.id.show_from_cache).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                getAdFromCacheAndShow();
                Log.i(TAG, "getAdFromCacheAndShow");

            }
        });

    }

    public void loadAd() {
        adLayout = (ViewGroup) View.inflate(SampleApplication.context, R.layout.advance_native_layout, null);  //广告布局

        SuibSDK.getNativeAd(Config.slotIdNative, SampleApplication.context, new MyCTAdEventListener() {

            @Override
            public void onReceiveAdSucceed(ZCNative result) {
                if (result == null) {
                    return;
                }
                ZCAdvanceNative ctAdvanceNative = (ZCAdvanceNative) result;
                showAd(ctAdvanceNative);
                SLog.e("onReceiveAdSucceed");
                super.onReceiveAdSucceed(result);
            }


            @Override
            public void onReceiveAdFailed(com.suib.base.core.ZCNative result) {
                SLog.e("onReceiveAdFailed");
                super.onReceiveAdFailed(result);
            }


            @Override
            public void onAdClicked(com.suib.base.core.ZCNative result) {
                SLog.e("onAdClicked");
                super.onAdClicked(result);
            }

        });

    }

    private void loadAdForCache() {
        SuibSDK.getNativeAdForCache(Config.slotIdNative, SampleApplication.context, new MyCTAdEventListener() {
            @Override
            public void onReceiveAdVoSucceed(com.suib.base.vo.AdsNativeVO result) {
                if (result == null) {
                    return;
                }
                SLog.e("onReceiveAdVoSucceed");

                AdHolder.adNativeVO = result;
                super.onReceiveAdVoSucceed(result);

            }


            @Override
            public void onReceiveAdFailed(com.suib.base.core.ZCNative result) {
                SLog.e("onReceiveAdFailed");
                super.onReceiveAdFailed(result);
            }


            @Override
            public void onAdClicked(com.suib.base.core.ZCNative result) {
                SLog.e("onAdClicked");
                super.onAdClicked(result);
            }

        });
    }

    public void getAdFromCacheAndShow() {
        adLayout = (ViewGroup) View.inflate(SampleApplication.context, R.layout.advance_native_layout, null);  //广告布局

        com.suib.base.core.ZCAdvanceNative ctAdvanceNative = new com.suib.base.core.ZCAdvanceNative(getContext());

        com.suib.base.vo.AdsNativeVO nativeVO = AdHolder.adNativeVO;

        if (nativeVO != null) {
            ctAdvanceNative.setNativeVO(nativeVO);

            ctAdvanceNative.setSecondAdEventListener(new MyCTAdEventListener() {

                @Override
                public void onAdClicked(com.suib.base.core.ZCNative result) {
                    SLog.e("onAdClicked");
                    super.onAdClicked(result);
                }


            });

            showAd(ctAdvanceNative);
        }

    }

    private void showAd(final ZCAdvanceNative ctAdvanceNative) {

        SimpleDraweeView img = adLayout.findViewById(R.id.iv_img);
        SimpleDraweeView icon = adLayout.findViewById(R.id.iv_icon);
        TextView title = adLayout.findViewById(R.id.tv_title);
        TextView desc = adLayout.findViewById(R.id.tv_desc);
        TextView click = adLayout.findViewById(R.id.bt_click);
        SimpleDraweeView ad_choice_icon = adLayout.findViewById(R.id.ad_choice_icon);

        img.setImageURI(Uri.parse(ctAdvanceNative.getImageUrl()));
        icon.setImageURI(Uri.parse(ctAdvanceNative.getIconUrl()));
        title.setText(ctAdvanceNative.getTitle());
        desc.setText(ctAdvanceNative.getDesc());
        click.setText(ctAdvanceNative.getButtonStr());
        ad_choice_icon.setImageURI(ctAdvanceNative.getAdChoiceIconUrl());

        container.removeAllViews();

        //只是注册点击区域,调此处设置
        ctAdvanceNative.registeADClickArea(adLayout);
        container.addView(adLayout);

        ad_choice_icon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String linkUrl = ctAdvanceNative.getAdChoiceLinkUrl();
                if (TextUtils.isEmpty(linkUrl)) {
                    Toast.makeText(getContext(), "adChoiceLinkUrl is null", Toast.LENGTH_LONG).show();
                    return;
                }
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(linkUrl));
                if (browserIntent.resolveActivity(getContext().getPackageManager()) != null) {
                    startActivity(browserIntent);
                }
            }
        });
    }

}