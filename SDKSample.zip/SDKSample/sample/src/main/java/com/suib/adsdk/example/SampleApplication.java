package com.suib.adsdk.example;

import android.app.Application;
import android.content.Context;
import android.support.multidex.MultiDex;

import com.suib.adsdk.example.config.Config;
import com.facebook.drawee.backends.pipeline.Fresco;
import com.facebook.stetho.Stetho;
import com.squareup.leakcanary.LeakCanary;
import com.suib.base.core.SuibSDK;

/*
 * Created by huangdong on 16/9/20.
 */
public class SampleApplication extends Application {

    public static Context context;
    public static boolean hasSplash = false;


    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        MultiDex.install(this);
    }


    @Override
    public void onCreate() {
        super.onCreate();

        if (BuildConfig.DEBUG) {
            if (LeakCanary.isInAnalyzerProcess(this)) {
                return;
            }
            LeakCanary.install(this); // TODO: 2016/12/28 检测内存泄露
        }
        context = this.getApplicationContext();

//      initialize the sdk
        SuibSDK.initialize(context, Config.slotIdReward);
//        SuibSDK.setIsChildDirected(context,true);

//      initialize the fresco for sample
        Fresco.initialize(context);
        Stetho.initializeWithDefaults(this);
    }

}
