package com.suib.adsdk.example;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.suib.base.core.SuibSDK;
import com.suib.base.utils.HttpRequester;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initMainPage();
    }


    private void initMainPage() {
        showFragment(IndexAsListFragment.getInstance());

        SuibSDK.uploadConsent(this, true, "GDPR", new HttpRequester.Listener() {
            @Override
            public void onGetDataSucceed(byte[] data) {
            }


            @Override
            public void onGetDataFailed(String error) {
            }
        });
    }


    public void showFragment(Fragment fragment) {
        FragmentManager fragmentManager = this.getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.main_content, fragment);
        if (!(fragment instanceof IndexAsListFragment)) {
            fragmentTransaction.addToBackStack(null);
        }
        fragmentTransaction.commit();
    }


    public void showNativeFragment(android.app.Fragment fragment) {
        android.app.FragmentManager fragmentManager = this.getFragmentManager();
        android.app.FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.main_content, fragment);
        fragmentTransaction.addToBackStack("natvie_fragment");
        fragmentTransaction.commit();
    }


    @Override
    public void onBackPressed() {
        if (getFragmentManager().getBackStackEntryCount() > 0) {
            super.onBackPressed();
        }
        super.onBackPressed();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.sample_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.note:
                Toast.makeText(SampleApplication.context, "Googleplay is needed for ct-ads.", Toast.LENGTH_LONG).show();
                break;
            case R.id.mutilProcess:
                startActivity(new Intent(SampleApplication.context, NewProcessActivity.class));
                break;
            case R.id.setup:
                startActivity(new Intent(SampleApplication.context, SetupActivity.class));
                break;
            case R.id.hvScreen:
                // if (BuildConfig.DEBUG) {
                //     final String screen = "screen";
                //     if (!"h".equals(PreferenceTools.getString(screen))) {
                //         setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
                //         PreferenceTools.persistString(screen, "h");
                //     } else {
                //         setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
                //         PreferenceTools.persistString(screen, "v");
                //     }
                // }
                break;
        }
        return true;
    }

}
