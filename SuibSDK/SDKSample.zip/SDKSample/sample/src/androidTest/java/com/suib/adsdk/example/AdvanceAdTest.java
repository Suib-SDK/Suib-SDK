package com.suib.adsdk.example;

import android.app.Instrumentation;
import android.support.test.InstrumentationRegistry;
import android.support.test.espresso.DataInteraction;
import android.support.test.espresso.Espresso;
import android.support.test.espresso.IdlingPolicies;
import android.support.test.espresso.assertion.ViewAssertions;
import android.support.test.filters.LargeTest;
import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;

import com.suib.adsdk.example.utils.Constants;
import com.suib.adsdk.example.utils.PowersUtil;
import com.suib.adsdk.example.utils.RepeatRule;

import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.concurrent.TimeUnit;

import static android.support.test.espresso.Espresso.onData;
import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.matcher.ViewMatchers.hasChildCount;
import static android.support.test.espresso.matcher.ViewMatchers.isDisplayed;
import static android.support.test.espresso.matcher.ViewMatchers.withId;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.anything;

/**
 * Created by tujiantao on 2018/3/5.
 */
@LargeTest
@RunWith(AndroidJUnit4.class)
public class AdvanceAdTest {

    private final static String TAG = "AdvanceAdTest";

    @Rule
    public RepeatRule repeatRule = new RepeatRule();

    @Rule
    public ActivityTestRule<MainActivity> mActivityTestRule = new ActivityTestRule<>(MainActivity
            .class);


    private SimpleCountingIdlingResource getAdIdlingResource;

    private MainActivity activity;

    private Instrumentation instrumentation;

    private ViewGroup container;
    @BeforeClass
    public static void startClass(){
        IdlingPolicies.setMasterPolicyTimeout(100, TimeUnit.SECONDS);
        IdlingPolicies.setIdlingResourceTimeout(100, TimeUnit.SECONDS);
    }

    @Before
    public void start() throws InterruptedException {

        activity = mActivityTestRule.getActivity();
        instrumentation=InstrumentationRegistry.getInstrumentation();
        if (!PowersUtil.getScreenOn(activity) || PowersUtil.getLockScreenOn(activity)) {//解锁屏幕
            PowersUtil.wakeUpAndUnlock(activity);
        }
        Thread.sleep(2000);
        DataInteraction appCompatTextView = onData(anything())
                .inAdapterView(allOf(withId(R.id.listView),
                        childAtPosition(withId(R.id.main_content), 0))).atPosition(4);
        appCompatTextView.perform(click());
        container=(ViewGroup)activity.findViewById(R.id.container);


    }

    @Test
    @RepeatRule.Repeat( runCount =  Constants.TEST_COUNT )
    public void loadAdSuccess() {
        getAdIdlingResource = SimpleCountingIdlingResource.create("test2");
        Espresso.registerIdlingResources(getAdIdlingResource);
        Log.i(TAG, "threadId=" + Thread.currentThread().getId() + ",processName=" + Thread
                .currentThread().getName());
        Log.i(TAG, "LOAD AD SUCCESS 点击前");
        onView(withId(R.id.load_ad)).perform(click());
        Log.i(TAG, "LOAD AD SUCCESS");
        sleep(3000L);
        onView(allOf(withId(R.id.container), isDisplayed())).check(ViewAssertions.matches(hasChildCount(1)));
        instrumentation.runOnMainSync(new Runnable() {
            @Override
            public void run() {
                container.removeAllViews();
            }
        });
        Espresso.unregisterIdlingResources(getAdIdlingResource);
        getAdIdlingResource = SimpleCountingIdlingResource.create("test3");
        Espresso.registerIdlingResources(getAdIdlingResource);
        Log.i(TAG, "LOAD AD WITH IMAGE_PRELOAD SUCCESS 点击前");
        onView(withId(R.id.load_ad_imageload)).perform(click());
        Log.i(TAG, "LOAD AD WITH IMAGE_PRELOAD SUCCESS\n");
        sleep(3000L);
        onView(allOf(withId(R.id.container), isDisplayed())).check(ViewAssertions.matches(hasChildCount(1)));
        instrumentation.runOnMainSync(new Runnable() {
            @Override
            public void run() {
                container.removeAllViews();
            }
        });
        Espresso.unregisterIdlingResources(getAdIdlingResource);

        getAdIdlingResource = SimpleCountingIdlingResource.create("test4");
        Espresso.registerIdlingResources(getAdIdlingResource);
        Log.i(TAG, "LOAD AD FOR CACHE SUCCESS 点击前");
        onView(withId(R.id.load_for_cache)).perform(click());
        Log.i(TAG, "LOAD AD FOR CACHE SUCCESS\n");
        Espresso.unregisterIdlingResources(getAdIdlingResource);

        Log.i(TAG, "SHOW AD FOR CACHE SUCCESS点击前");
        onView(withId(R.id.show_from_cache)).perform(click());
        Log.i(TAG, "SHOW AD FOR CACHE SUCCESS\n");
        sleep(3000L);
        onView(allOf(withId(R.id.container), isDisplayed())).check(ViewAssertions.matches(hasChildCount(1)));
    }


    @After
    public void stop() {
        Espresso.unregisterIdlingResources(getAdIdlingResource);
    }

    private void sleep(Long time){
        try {
            Thread.sleep(time);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private static Matcher<View> childAtPosition(
            final Matcher<View> parentMatcher, final int position) {

        return new TypeSafeMatcher<View>() {
            @Override
            public void describeTo(Description description) {
                description.appendText("Child at position " + position + " in parent ");
                parentMatcher.describeTo(description);
            }

            @Override
            public boolean matchesSafely(View view) {
                ViewParent parent = view.getParent();
                return parent instanceof ViewGroup && parentMatcher.matches(parent)
                        && view.equals(((ViewGroup) parent).getChildAt(position));
            }
        };
    }

}
