package com.suib.mediation.mopub;

import android.content.Context;
import android.util.Log;

import com.mopub.mobileads.CustomEventInterstitial;
import com.mopub.mobileads.MoPubErrorCode;
import com.suib.base.callback.AdEventListener;
import com.suib.base.core.SuibSDK;
import com.suib.base.core.ZCNative;
import com.suib.base.vo.AdsNativeVO;

import java.util.Map;

class ZCAdapterInterstitial extends CustomEventInterstitial {

    private CustomEventInterstitialListener mInterstitialListener;
    private ZCNative zcNative;

    private static final String TAG = "CTAdapterFullScreen";

    /*
     * Abstract methods from CustomEventInterstitial
     */
    @Override
    protected void loadInterstitial(final Context context,
                                    final CustomEventInterstitialListener interstitialListener,
                                    final Map<String, Object> localExtras,
                                    final Map<String, String> serverExtras) {
        mInterstitialListener = interstitialListener;
        final String ctSlotId;
        Log.e(TAG, "loadInterstitial: localExtras -> " + localExtras + ", serverExtras -> " +
            serverExtras);
        if (extrasAreValid(serverExtras)) {
            ctSlotId = serverExtras.get(ZCHelper.KEY_CT_SLOTID);
        } else {
            mInterstitialListener.onInterstitialFailed(MoPubErrorCode.INTERNAL_ERROR);
            return;
        }

        SuibSDK.initialize(context, ctSlotId);
        SuibSDK.preloadInterstitialAd(context, ctSlotId, new AdEventListener() {

            @Override
            public void onReceiveAdSucceed(ZCNative result) {
                //在广告加载成功之后再show,不然会出一个空白
                zcNative = result;

                mInterstitialListener.onInterstitialLoaded();
            }


            @Override
            public void onReceiveAdVoSucceed(AdsNativeVO result) {

            }


            @Override
            public void onInterstitialLoadSucceed(ZCNative result) {

            }


            @Override
            public void onReceiveAdFailed(ZCNative result) {
                mInterstitialListener.onInterstitialFailed(MoPubErrorCode.NETWORK_NO_FILL);
            }


            @Override
            public void onLandpageShown(ZCNative result) {

            }


            @Override
            public void onAdClicked(ZCNative result) {
                mInterstitialListener.onInterstitialClicked();
            }


            @Override
            public void onAdClosed(ZCNative result) {
                mInterstitialListener.onInterstitialDismissed();
            }

        });

    }


    private static boolean extrasAreValid(Map<String, String> extras) {
        return extras.containsKey(ZCHelper.KEY_CT_SLOTID);
    }


    @Override
    protected void showInterstitial() {
        if (SuibSDK.isInterstitialAvailable(zcNative)) {
            SuibSDK.showInterstitialAd(zcNative);
            mInterstitialListener.onInterstitialShown();
        } else {
            mInterstitialListener.onInterstitialFailed(MoPubErrorCode.NETWORK_INVALID_STATE);
        }
    }


    @Override
    protected void onInvalidate() {
        //mGreystripeAd.removeListener(this);
    }

}
